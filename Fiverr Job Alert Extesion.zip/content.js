
const projects = document.querySelector('.js-db-status-tabs a').getAttribute('data-count');
const body = document.querySelector('body');
const url_ = "https://www.fiverr.com/users/rimon_islam2003/requests*";
var reloadPage = true;
const stopButton = document.createElement('button');
const audio_tag = document.createElement('audio');
body.append(audio_tag);
audio_tag.setAttribute('src', 'https://assets.mixkit.co/sfx/preview/mixkit-clear-announce-tones-2861.mp3');
audio_tag.setAttribute('controls', ''); // or audio_tag.controls = true;
audio_tag.setAttribute('style', 'top:0;left:0;position:fixed;display:none');
var display = 'none';

if (projects > 0) {
    setInterval(() => { update() }, 300000) // every 5 minutes;
    update();
    function update() {
        audio_tag.loop = true;

        audio_tag.oncanplay = function() {
        audio_tag.setAttribute('autoplay', '');            
        }
        audio_tag.setAttribute('autoplay', '');           
        const title = document.querySelector('title');
        title.innerHTML = `${projects} Project(s) Found`;
        reloadPage = false;
        refreshPage();
        display = 'block';
    }
}

stopButton.setAttribute('style', `background:black;z-index:1000000;display:${display};color:green;top:0;left:45%;position:fixed;width:200px;padding:5px;border:2px solid limegreen;`);
stopButton.innerHTML = 'Stop Until Next Visit';
body.append(stopButton);

stopButton.addEventListener('click', function () {
    this.style.display = 'none';
    stopAudio();
})


function stopAudio() {
    audio_tag.pause();
    reloadPage = false
    refreshPage();
}
refreshPage()
function refreshPage() {
    const url = window.location.href;
    if (true) {
        if (reloadPage) {
            setInterval(() => {
                window.location.href = url;
            }, 5000)      // every 5 seconds      
        }

    }
}
